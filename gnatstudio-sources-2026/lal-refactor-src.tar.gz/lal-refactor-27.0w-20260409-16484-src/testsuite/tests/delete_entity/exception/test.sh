cp ./main.orig ./main.adb
delete_entity -P default.gpr -S main.adb -L 2 -R 14
echo "--  (main.orig) -L 2 -R 14"
cat ./main.adb

cp ./main2.orig ./main.adb
delete_entity -P default.gpr -S main.adb -L 2 -R 14
echo "--  (main2.orig) -L 2 -R 14"
cat ./main.adb
