gnatpp --pipe p.ads
