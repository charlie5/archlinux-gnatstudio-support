--
--  Copyright (C) <YEAR>, <COPYRIGHT HOLDER>
--
--  SPDX-License-Identifier: MIT
--
--  DON'T EDIT THIS FILE! It was generated from metaModel.json.
--

package body LSP.Client_Notifications.CancelRequest is

   overriding procedure Visit_Client_Receiver
     (Self  : Notification;
      Value : in out LSP.Client_Notification_Receivers
        .Client_Notification_Receiver'
        Class) is
   begin
      Value.On_CancelRequest_Notification (Self.Params);
   end Visit_Client_Receiver;

end LSP.Client_Notifications.CancelRequest;
