--
--  Copyright (C) 2023-2026, AdaCore
--
--  SPDX-License-Identifier: Apache-2.0 WITH LLVM-Exception
--

--  This package provides a way to import/export adacore & non-adacore
--  tools GPR registy. Export support is provided in GPR2.Options package
--  through a new Print_GPR_Registry option. ("--print-gpr-registry")
--  Use GPR2.Options.Print_GPR_Registry API to print registry & exit if needed.
--  Textual (export only), JSON & JSON_COMPACT formats are supported.
--  exported/imported packages can be filtered. Default filter excludes
--  project level scope attributes & all packages defined by GPR2 library.

with Ada.Strings.Unbounded;
with Ada.Text_IO;

with GPR2.Containers;
with GPR2.Project.Registry.Pack;

package GPR2.Project.Registry.Exchange is

   use Ada;
   use Ada.Strings.Unbounded;

   type Export_Format is (K_TEXT, K_JSON, K_JSON_COMPACT);
   --  Supported export format

   procedure Export
     (Included : Containers.Package_Id_List :=
                   Registry.Pack.All_Packages;
      Excluded : Containers.Package_Id_List :=
                   Registry.Pack.Predefined_Packages;
      Format   : Export_Format := K_JSON_COMPACT;
      Output   : access procedure (Item : String) := Text_IO.Put'Access);
   --  Export Packages filtered by Included/Excluded using right formating
   --  By default export all packages added after gpr2 initialization.

   procedure Import
     (Definitions : Unbounded_String;
      Included    : Containers.Package_Id_List :=
                      Containers.Package_Id_Type_List.Empty;
      Excluded    : Containers.Package_Id_List :=
                      Registry.Pack.Predefined_Packages);
   --  Import in registry Definitions (in JSON format) filtered by
   --  Included/Excluded parameters.
   --  By default import all definitions except project scope and gpr2
   --  predefined packages.
   --  Raise GNATCOLL.JSON.Invalid_JSON_Stream exception if Definitions is an
   --  invalid JSON string.

   procedure Import (File : GPR2.Path_Name.Object)
     with Pre => File.Is_Defined and then File.Exists;
   --  Import in registry definitions from File (in JSON format).
   --  Raise GNATCOLL.JSON.Invalid_JSON_Stream exception if File content is an
   --  invalid JSON string.

end GPR2.Project.Registry.Exchange;
