CREATE TABLE colors (name text, value int);
INSERT INTO colors (name, value) VALUES ('red', 1), ('green', 2), ('dark gray', 3);
.quit
