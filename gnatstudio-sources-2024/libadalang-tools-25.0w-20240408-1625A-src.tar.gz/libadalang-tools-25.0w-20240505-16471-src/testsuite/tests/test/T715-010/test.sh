gnattest -P p -q
gprbuild -P gnattest/harness/test_driver.gpr -q
gnattest/harness/test_runner
