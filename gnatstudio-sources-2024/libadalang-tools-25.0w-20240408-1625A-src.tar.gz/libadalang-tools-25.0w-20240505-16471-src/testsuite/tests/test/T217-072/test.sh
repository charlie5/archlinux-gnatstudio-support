gnattest -q -P p.gpr
