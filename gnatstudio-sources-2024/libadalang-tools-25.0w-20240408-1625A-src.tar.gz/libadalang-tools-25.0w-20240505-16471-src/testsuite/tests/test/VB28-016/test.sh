gnattest -q -P root.gpr --stub --stubs-dir=../some_other_dir
gprbuild -P obj/gnattest_stub/harness/test_drivers.gpr -q
