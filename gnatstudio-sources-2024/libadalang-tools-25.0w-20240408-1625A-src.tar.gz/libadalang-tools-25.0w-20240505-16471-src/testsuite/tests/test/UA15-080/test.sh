gnattest -P simple_ext.gpr --no-subprojects -q
gprbuild -P gnattest/harness/test_driver.gpr -q
