#!/bin/bash

GNATTEST_STRICT=False gnattest -P p --stub importing.ads -q
