# Simply test that gnattest does not crash when generating test vectors
gnattest -P test.gpr --gen-test-vectors -q
