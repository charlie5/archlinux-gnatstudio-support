gnattest -P contracts.gpr -q
gnattest -P contracts.gpr -q -XGNATTEST_SOURCE_SELECT=after
