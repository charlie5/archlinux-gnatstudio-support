gnattest -P simple -q
gprbuild -P gnattest/harness/test_driver.gpr -q
