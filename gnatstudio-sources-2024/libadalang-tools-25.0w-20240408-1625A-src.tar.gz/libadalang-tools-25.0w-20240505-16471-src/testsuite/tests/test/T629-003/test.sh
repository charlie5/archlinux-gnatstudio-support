gnattest -P ops.gpr -q --stub
