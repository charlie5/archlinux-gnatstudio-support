#!/bin/bash

gnattest -q -P prj.gpr --gen-test-vectors --enum-strat --gen-test-num=0
gprbuild -P obj/gnattest/harness/test_driver.gpr -q
./obj/gnattest/harness/test_runner
