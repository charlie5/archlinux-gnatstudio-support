gnattest -P p --stub -q simple.ads simple.adb
