gnattest simple.gpr -q --stub
gprbuild -P gnattest_stub/harness/test_drivers.gpr -q
