gnatpp --pipe p.ads --keyword_upper_case --attribute_lower_case --name_lower_case --pragma_upper_case --alignment --max_line_length=101

gnatpp --pipe p.ads -kU -aL -nL -pU -A1 -A2 -A3 -A4 -A5 -M101 --no-separate-is --no-separate-loop-then --use-on-new-line --separate-stmt-name --preserve-blank-lines
