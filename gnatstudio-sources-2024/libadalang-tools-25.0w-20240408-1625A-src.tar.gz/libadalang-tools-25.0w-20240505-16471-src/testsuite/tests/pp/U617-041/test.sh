gnatpp --pipe --templates=gnatpp_templates.json --output-dir=actual main.adb
