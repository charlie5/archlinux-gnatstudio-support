echo "Testing --split-line-before-op switch"

gnatpp -P default.gpr main.adb --split-line-before-op --pipe
