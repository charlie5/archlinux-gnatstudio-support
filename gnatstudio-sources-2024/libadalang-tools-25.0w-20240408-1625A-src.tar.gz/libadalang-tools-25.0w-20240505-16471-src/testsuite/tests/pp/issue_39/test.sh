gnatpp main.adb --layout=compact --pipe
gnatpp main.adb --layout=tall --pipe

