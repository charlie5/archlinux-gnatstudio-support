gnatpp --pipe -nM main.adb
echo ""
gnatpp --pipe -nM -cN main.adb
echo ""
gnatpp --pipe -nM -cD main.adb
echo ""
gnatpp --pipe -nM -cU main.adb
echo ""
gnatpp --pipe -nM -cL main.adb
echo ""
gnatpp --pipe -nM -cM main.adb
