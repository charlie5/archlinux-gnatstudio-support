gnatpp source.ada -q --pipe
