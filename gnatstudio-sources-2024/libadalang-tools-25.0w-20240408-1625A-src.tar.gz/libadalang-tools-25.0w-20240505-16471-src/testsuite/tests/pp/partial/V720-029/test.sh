
partial_gnatpp -P default.gpr -S main.adb -SL 4 -EL 4 -EC 90
partial_gnatpp -P default.gpr -S main.adb -SL 1 -EL 4 -EC 90

