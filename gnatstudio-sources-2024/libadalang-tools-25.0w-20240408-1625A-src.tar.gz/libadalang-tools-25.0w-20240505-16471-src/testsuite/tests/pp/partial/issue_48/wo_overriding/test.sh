partial_gnatpp -P default.gpr -S test.ads -SL 3 -SC 9 -EL 3 -EC 13
partial_gnatpp -P default.gpr -S test.adb -SL 3 -SC 9 -EL 3 -EC 13
