partial_gnatpp -P default.gpr -S main.adb -SL 4 -SC 8 -EL 5 -EC 7
partial_gnatpp -P default.gpr -S main.adb -SL 5 -SC 7 -EL 5 -EC 8
