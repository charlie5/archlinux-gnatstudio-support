#! /usr/bin/env bash

partial_gnatpp -P default.gpr -S main.adb -SL 2 -SC 5 -EL 4 -EC 5




