#! /usr/bin/env bash

partial_gnatpp -P default.gpr -S main.adb -SL 6 -SC 8 -EL 12 -EC 7

