partial_gnatpp -P default.gpr -S src/main.adb -SL 4 -SC 4 -EL 9 -EC 4
