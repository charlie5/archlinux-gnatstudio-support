
echo "-----------------------------------------------------------------"
echo "       Package declarations testing"
partial_gnatpp -P default.gpr -S package_declaration.ads -SL 25 -EL 39 -EC 26
