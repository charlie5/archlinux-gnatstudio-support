echo "test_begin.adb"
indent -P default.gpr -S test_begin.adb -L 4
echo "test_declare.adb"
indent -P default.gpr -S test_declare.adb -L 4
