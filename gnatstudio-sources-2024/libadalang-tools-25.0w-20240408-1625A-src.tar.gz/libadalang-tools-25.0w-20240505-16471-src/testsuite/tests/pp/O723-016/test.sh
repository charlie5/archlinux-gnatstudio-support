gnatpp -q foo.adb -nM -neM -neD --no-separate-loop-then --no-separate-is --separate-stmt-name --use-on-new-line -M120 –decimal-grouping=3 –based-grouping=4 -pipe
