gnatpp --pipe p.adb
gnatpp --pipe p2.adb
gnatpp --pipe q.adb
