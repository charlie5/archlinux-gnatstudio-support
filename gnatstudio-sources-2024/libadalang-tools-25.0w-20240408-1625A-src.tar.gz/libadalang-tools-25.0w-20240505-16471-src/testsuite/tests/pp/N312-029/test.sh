gnatpp --pipe sample_formatting.adb
gnatpp --pipe sample_formatting.adb --indent-named-statements
