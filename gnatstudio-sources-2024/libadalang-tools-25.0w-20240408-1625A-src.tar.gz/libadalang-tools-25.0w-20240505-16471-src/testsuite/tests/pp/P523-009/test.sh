gnatpp -q --pipe --vertical-enum-types *.ads *.adb *.ada
