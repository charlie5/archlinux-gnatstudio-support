gnatpp left_hand_side.adb -pipe
