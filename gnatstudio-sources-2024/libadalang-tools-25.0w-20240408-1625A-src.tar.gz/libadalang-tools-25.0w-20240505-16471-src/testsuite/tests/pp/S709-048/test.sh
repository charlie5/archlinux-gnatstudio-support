gnatpp --pipe p.ads
gnatpp --pipe p.ads --rm-style-spacing
gnatpp --pipe p.ads --rm-style-spacing --alignment
