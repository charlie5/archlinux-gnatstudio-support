gnatpp --pipe --layout=tall foo.adb

