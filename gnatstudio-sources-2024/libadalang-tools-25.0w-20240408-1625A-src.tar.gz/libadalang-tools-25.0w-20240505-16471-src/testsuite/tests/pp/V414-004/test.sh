gnatpp -pipe test.adb
