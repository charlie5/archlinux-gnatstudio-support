gnatpp --pipe mixed_keywords.adb
