gnatpp -q --pipe test.ads
