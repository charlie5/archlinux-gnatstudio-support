gnatpp --layout=tall --no-c3 --pipe test.ads
