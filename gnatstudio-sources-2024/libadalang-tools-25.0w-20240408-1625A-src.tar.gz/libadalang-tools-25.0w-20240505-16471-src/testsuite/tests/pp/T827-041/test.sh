gnatmetric -q -Pprojectall.gpr -U --short-file-names
