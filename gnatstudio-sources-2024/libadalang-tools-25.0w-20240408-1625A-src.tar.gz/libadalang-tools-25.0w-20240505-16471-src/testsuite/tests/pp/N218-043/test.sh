gnatpp --pipe --vertical-enum-types directions.ads
