gnatpp --pipe align_test.ads
