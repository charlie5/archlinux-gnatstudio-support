gnatpp --pipe main.adb
