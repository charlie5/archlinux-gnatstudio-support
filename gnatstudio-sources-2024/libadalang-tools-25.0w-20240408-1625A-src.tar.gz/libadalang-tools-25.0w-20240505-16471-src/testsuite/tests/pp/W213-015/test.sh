gnatpp -P check.gpr --pipe
