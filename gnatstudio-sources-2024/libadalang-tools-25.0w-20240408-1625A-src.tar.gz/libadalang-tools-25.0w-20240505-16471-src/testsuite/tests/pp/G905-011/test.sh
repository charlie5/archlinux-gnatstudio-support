gnatpp --pipe gnatpp_array_formatting.adb
gnatpp --pipe gnatpp_exdentation.adb
gnatpp --pipe test.ada
