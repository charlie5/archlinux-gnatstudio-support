gnatpp --pipe test.ads

gnatpp\
	 --name-mixed-case\
	 --attribute-mixed-case\
	 --keyword-lower-case\
	 --enum-mixed-case\
	 --type-mixed-case\
	 --number-mixed-case\
	 --pragma-mixed-case\
	 --comments-gnat-indentation\
	 --comments-special\
	 --preserve-blank-lines\
	 --max-line-length=256\
	 --indentation=3\
	 --decimal-grouping=3\
	 --based-grouping=4\
	 --split-line-before-record\
	 --indent-named-statements\
	 --no-compact\
	 --vertical-enum-types\
	 --vertical-array-types\
	 --pipe\
	 test.ads

