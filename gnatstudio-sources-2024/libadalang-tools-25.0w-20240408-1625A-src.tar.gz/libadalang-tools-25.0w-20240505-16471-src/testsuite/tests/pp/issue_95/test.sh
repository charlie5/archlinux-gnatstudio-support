gnatpp --pipe test.ads
gnatpp --separate-overriding --pipe test.ads

