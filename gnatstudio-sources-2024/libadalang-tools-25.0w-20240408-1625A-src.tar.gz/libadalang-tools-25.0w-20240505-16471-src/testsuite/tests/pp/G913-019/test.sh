gnatpp --pipe test.adb --par-threshold=1 --call-threshold=1 --vertical-named-aggregates
