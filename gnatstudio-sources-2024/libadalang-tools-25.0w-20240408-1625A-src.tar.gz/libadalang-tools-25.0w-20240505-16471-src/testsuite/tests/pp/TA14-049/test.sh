gnatpp -Pp -U
cat q/q.ads
gnatpp -Pp q.ads || true
