gnatmetric -debugv -P ./ada_playground.gpr -nt --short-file-names -U
cat metrix.xml
