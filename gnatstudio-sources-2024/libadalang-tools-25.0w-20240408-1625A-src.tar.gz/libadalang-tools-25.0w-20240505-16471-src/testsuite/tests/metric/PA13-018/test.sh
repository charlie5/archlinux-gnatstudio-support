gnatmetric -Pprj.gpr -q -x -sfn --metrics-all
cat obj/*.metrix
cat obj/metrix.xml
