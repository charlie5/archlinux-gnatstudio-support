gnatmetric -P aggr.gpr -U --short-file-names
