gnatstub -P my_project.gpr --subunits --update-body=2 my_package.ads
