gnatstub --quiet --force p.ads
cat p.adb
