gnatstub --quiet --force p.ads --no-exception
cat p.adb
