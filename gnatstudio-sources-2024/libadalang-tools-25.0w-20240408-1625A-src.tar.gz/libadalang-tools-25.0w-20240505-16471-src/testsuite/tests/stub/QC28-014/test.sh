gnatstub --help
