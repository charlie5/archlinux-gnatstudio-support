gnatstub example.ads
