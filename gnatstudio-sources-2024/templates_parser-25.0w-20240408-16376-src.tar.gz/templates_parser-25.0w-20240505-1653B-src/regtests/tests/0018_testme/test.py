from test_support import *

run('testme', ["testme31.tmplt"])
run('print_tree', ["testme31.tmplt"])
