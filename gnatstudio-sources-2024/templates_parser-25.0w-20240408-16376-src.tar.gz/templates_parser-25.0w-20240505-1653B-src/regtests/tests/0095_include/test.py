from test_support import *

gprbuild('include')
run('include')
