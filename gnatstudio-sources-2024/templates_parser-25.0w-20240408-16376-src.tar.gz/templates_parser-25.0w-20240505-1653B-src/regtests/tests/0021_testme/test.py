from test_support import *

run('testme', ["testme53.tmplt"])
run('print_tree', ["testme53.tmplt"])
