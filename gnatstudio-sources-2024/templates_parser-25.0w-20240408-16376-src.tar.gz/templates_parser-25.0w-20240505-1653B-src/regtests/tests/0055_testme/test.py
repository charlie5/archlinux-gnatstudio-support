from test_support import *

run('testme', ["testme51.tmplt"])
