from test_support import *

run('testme', ["testme69.tmplt"])
