from test_support import *

run('testme', ["testme10.tmplt", "kut"])
run('print_tree', ["testme10.tmplt"])
