from test_support import *

run('testme', ["testme32.tmplt"])
run('print_tree', ["testme32.tmplt"])
