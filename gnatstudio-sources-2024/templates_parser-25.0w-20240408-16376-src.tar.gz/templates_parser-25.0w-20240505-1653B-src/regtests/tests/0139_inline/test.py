from test_support import *

run('testme', ["testinline.tmplt"])
