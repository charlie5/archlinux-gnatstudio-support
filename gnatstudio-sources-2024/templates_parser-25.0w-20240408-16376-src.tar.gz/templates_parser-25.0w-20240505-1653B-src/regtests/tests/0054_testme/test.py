from test_support import *

run('testme', ["testme50.tmplt"])
