from test_support import *

run('testme', ["blocks5.tmplt"])
