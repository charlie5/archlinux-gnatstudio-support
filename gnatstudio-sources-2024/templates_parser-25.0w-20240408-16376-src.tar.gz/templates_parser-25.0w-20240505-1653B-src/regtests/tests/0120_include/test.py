from test_support import *

run('print_tree', ["src.tmpl"])
run('testme', ["src.tmpl"])
