from test_support import *

gprbuild('tag_demo')
run('tag_demo')
