from test_support import *

run('testme', ["testme49.tmplt"])
