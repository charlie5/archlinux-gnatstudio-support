from test_support import *

gprbuild('regtst1')
run('regtst1')
