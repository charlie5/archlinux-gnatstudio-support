from test_support import *

gprbuild('not_initialized')
run('not_initialized')
