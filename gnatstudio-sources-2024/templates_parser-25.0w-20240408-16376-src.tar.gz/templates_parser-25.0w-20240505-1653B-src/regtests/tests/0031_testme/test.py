from test_support import *

run('testme', ["testme19.tmplt"])
