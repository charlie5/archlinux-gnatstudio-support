from test_support import *

run('print_tree', ["ftp.tmplt"])
