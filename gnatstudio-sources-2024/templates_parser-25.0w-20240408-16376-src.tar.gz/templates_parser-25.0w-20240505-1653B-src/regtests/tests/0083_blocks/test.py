from test_support import *

run('testme', ["blocks4.tmplt"])
run('print_tree', ["blocks4.tmplt"])
