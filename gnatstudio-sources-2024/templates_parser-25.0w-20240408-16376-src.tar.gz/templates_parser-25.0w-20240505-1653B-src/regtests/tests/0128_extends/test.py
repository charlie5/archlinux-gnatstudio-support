from test_support import *
run('testme', ["extends.thtml"])
