from test_support import *

run('testme', ["testme26.tmplt"])
run('print_tree', ["testme26.tmplt"])
