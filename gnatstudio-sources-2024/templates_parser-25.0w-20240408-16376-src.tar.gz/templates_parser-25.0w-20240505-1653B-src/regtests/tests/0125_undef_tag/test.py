from test_support import *

gprbuild('undef_tag')
run('undef_tag')
