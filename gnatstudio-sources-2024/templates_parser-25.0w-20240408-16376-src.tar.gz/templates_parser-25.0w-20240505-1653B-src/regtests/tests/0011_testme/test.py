from test_support import *

run('testme', ["testme17.tmplt"])
run('print_tree', ["testme17.tmplt"])
