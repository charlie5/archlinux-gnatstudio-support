from test_support import *

run('print_tree', ["widget_counter.thtml"])
run('testme', ["widget_counter.thtml"])
