from test_support import *

run('testme', ["testme11.tmplt"])
run('print_tree', ["testme11.tmplt"])
