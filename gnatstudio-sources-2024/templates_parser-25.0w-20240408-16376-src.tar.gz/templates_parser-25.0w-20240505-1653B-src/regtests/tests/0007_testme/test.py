from test_support import *

run('testme', ["testme8.tmplt"])
run('print_tree', ["testme8.tmplt"])
