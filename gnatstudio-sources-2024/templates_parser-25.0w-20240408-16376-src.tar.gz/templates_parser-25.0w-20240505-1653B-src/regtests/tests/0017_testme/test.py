from test_support import *

run('testme', ["testme30.tmplt"])
run('print_tree', ["testme30.tmplt"])
