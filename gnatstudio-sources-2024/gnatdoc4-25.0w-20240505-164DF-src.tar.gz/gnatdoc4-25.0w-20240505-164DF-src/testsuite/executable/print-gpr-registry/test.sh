$GNATDOC4 --print-gpr-registry
