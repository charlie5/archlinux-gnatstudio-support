.. GNATdoc documentation master file

GNATdoc
=======

**Contents:**

.. toctree::
   :maxdepth: 2

   introduction
   annotations
   configuration
   backends

Search and indices
==================

* :ref:`search`
* :ref:`genindex`

This document may be copied, in whole or in part, in any form or by any
means, as is or with alterations, provided that (1) alterations are clearly
marked as alterations and (2) this copyright notice is included
unmodified in any copy.

