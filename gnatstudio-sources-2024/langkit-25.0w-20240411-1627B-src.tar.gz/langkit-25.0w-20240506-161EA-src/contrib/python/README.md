Python parser
=============

This is a Python parser written on top of Langkit. It is meant as a full
example of what can be done with Langkit in terms of parsing, besides
Libadalang itself.

Build
-----

```sh
$ ./manage.py make
```

Parse python
------------

```sh
build/bin/parse -f my_python_file.py
```
