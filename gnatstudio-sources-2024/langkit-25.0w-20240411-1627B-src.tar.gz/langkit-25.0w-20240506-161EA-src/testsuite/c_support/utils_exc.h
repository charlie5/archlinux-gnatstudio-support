#ifndef UTILS_EXC_H
#define UTILS_EXC_H

#include <stdbool.h>

extern bool print_exception (bool or_silent);
extern void abort_on_exception (void);

#endif /* UTILS_EXC_H */
