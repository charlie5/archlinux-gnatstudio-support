#! /usr/bin/env python

from langkit.scripts.create_project import main


main()
