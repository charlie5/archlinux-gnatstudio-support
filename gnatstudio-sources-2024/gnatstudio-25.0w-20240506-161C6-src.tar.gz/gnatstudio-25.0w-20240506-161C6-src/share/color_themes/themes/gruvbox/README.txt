Imported from https://github.com/Briles/gruvbox
