# This package contains various utility modules used internally
# in both default GPS plug-ins and in the GPS testsuite
