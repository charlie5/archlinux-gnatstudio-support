#!/usr/bin/env sh

# This is a convenience command-line driver made for development mode
./run-tests --noxvfb  --show-error-output $@
