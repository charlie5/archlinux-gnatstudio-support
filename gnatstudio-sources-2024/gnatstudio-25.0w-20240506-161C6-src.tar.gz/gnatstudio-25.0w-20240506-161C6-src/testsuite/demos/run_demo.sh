#!/bin/sh
# usage: ./run_sh -d <path_to_demo_dir>

python demo_runner.py "$@"
