Testsuite
=========

This project has several testsuite tools

## Tester

[Tester](ada_lsp/README.md) emulates LSP client.
It reads commands from JSON file and executes them. See more details in
[Tester](ada_lsp/README.md).

