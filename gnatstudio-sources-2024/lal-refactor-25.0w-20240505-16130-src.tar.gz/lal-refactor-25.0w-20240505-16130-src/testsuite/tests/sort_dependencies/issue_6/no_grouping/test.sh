#!/bin/sh

sort_dependencies -P default.gpr -S main.adb --no-separator
