replace_type -P default.gpr -S test.ads -SL 3 -SC 10

