pull_up_declaration -P default.gpr --source foo.ads --line 3 --column 17
