pull_up_declaration -P test.gpr --source test.adb --line 7 --column 18
