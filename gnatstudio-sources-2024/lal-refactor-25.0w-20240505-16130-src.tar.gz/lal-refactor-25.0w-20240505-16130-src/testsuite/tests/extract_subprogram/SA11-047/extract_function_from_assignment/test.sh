extract_subprogram -P default.gpr -S my_package.adb -SL 13 -SC 13 -EL 13 -EC 14 -N Foo

