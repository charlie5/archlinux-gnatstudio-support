# Test cases on Procedure_A
extract_subprogram -P default.gpr -S main.adb -SL 7 -SC 7 -EL 14 -EC 8 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 9 -SC 20 -EL 9 -EC 25 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 7 -SC 6 -EL 7 -EC 14 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 7 -SC 7 -EL 7 -EC 8 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 7 -SC 7 -EL 8 -EC 7 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 7 -SC 7 -EL 9 -EC 13 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 7 -SC 7 -EL 13 -EC 7 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 9 -SC 13 -EL 9 -EC 23 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 9 -SC 13 -EL 9 -EC 36 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 9 -SC 13 -EL 10 -EC 3 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 9 -SC 13 -EL 10 -EC 10 -N Foo
## Test cases on Procedure_B
extract_subprogram -P default.gpr -S main.adb -SL 25 -SC 7 -EL 28 -EC 22 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 27 -SC 7 -EL 36 -EC 7 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 31 -SC 7 -EL 40 -EC 7 -N Foo
## Test cases on Procedure_C
extract_subprogram -P default.gpr -S main.adb -SL 52 -SC 10 -EL 52 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 51 -SC 10 -EL 52 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 53 -SC 10 -EL 53 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 52 -SC 10 -EL 53 -EC 10 -N Foo
## Test cases on Procedure_D
extract_subprogram -P default.gpr -S main.adb -SL 62 -SC 10 -EL 62 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 63 -SC 10 -EL 63 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 66 -SC 10 -EL 66 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 65 -SC 10 -EL 66 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 67 -SC 10 -EL 67 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 66 -SC 10 -EL 67 -EC 10 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 67 -SC 10 -EL 68 -EC 10 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 68 -SC 10 -EL 69 -EC 10 -N Foo
## Test cases on Procedure_E
extract_subprogram -P default.gpr -S main.adb -SL 82 -SC 16 -EL 83 -EC 16 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 82 -SC 16 -EL 84 -EC 16 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 81 -SC 16 -EL 83 -EC 16 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 81 -SC 16 -EL 83 -EC 28 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 81 -SC 16 -EL 84 -EC 16 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 81 -SC 16 -EL 85 -EC 16 -N Foo
## Test cases on Procedure_F
extract_subprogram -P default.gpr -S main.adb -SL 102 -SC 10 -EL 104 -EC 10 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 103 -SC 10 -EL 105 -EC 10 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 106 -SC 10 -EL 106 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 107 -SC 10 -EL 107 -EC 11 -N Foo
## Test cases on Procedure_G
extract_subprogram -P default.gpr -S main.adb -SL 115 -SC 10 -EL 117 -EC 10 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 116 -SC 10 -EL 117 -EC 37 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 117 -SC 10 -EL 117 -EC 11 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 117 -SC 10 -EL 117 -EC 37 -N Foo
extract_subprogram -P default.gpr -S main.adb -SL 120 -SC 10 -EL 120 -EC 11 -N Foo

