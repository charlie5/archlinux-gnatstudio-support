change_parameters_type -P test.gpr --source=src/my_lib.ads --start-line=2 --start-column=21 --end-line=2 --end-column=21 --new-parameter-type=Boolean
