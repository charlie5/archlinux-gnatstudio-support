change_parameters_default_value -P test.gpr --source=src/my_lib.ads --start-line=2 --start-column=21 --end-line=3 --end-column=22 --new-parameter-default-value=2
