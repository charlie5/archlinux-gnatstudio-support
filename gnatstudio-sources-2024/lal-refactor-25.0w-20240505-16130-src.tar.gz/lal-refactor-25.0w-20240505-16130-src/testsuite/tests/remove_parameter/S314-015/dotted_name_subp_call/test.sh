#!/bin/sh
remove_parameter -P default.gpr -S my_package.ads -L 3 -R 32
