#!/bin/sh
remove_parameter -P default.gpr -S main.adb -L 2 -R 14
