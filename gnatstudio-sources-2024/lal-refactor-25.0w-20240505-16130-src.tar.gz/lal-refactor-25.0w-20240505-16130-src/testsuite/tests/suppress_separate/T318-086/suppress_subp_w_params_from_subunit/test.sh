#!/bin/sh
suppress_separate -P default.gpr -S test-baz.adb -L 5 -R 10
