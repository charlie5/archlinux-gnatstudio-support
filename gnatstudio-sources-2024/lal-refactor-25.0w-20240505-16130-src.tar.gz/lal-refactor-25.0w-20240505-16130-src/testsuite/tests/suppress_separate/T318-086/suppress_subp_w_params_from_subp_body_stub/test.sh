#!/bin/sh
suppress_separate -P default.gpr -S test.adb -L 2 -R 14
