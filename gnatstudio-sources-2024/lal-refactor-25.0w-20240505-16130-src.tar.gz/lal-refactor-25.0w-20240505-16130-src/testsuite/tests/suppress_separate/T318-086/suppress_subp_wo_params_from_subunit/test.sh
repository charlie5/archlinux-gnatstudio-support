#!/bin/sh
suppress_separate -P default.gpr -S test-bar.adb -L 10 -R 27
