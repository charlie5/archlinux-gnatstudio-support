#!/bin/sh
suppress_separate -P default.gpr -S test.adb -L 3 -R 14
