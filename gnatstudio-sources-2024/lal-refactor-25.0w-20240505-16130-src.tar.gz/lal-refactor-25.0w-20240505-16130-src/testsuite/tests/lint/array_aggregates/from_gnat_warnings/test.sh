lalrefactor array_aggregates --from-gnat-warnings gprbuild_log --remove-indices --pipe
