lalrefactor array_aggregates -P test.gpr -S main.adb src/my_package.ads --remove-indices --pipe
