lalrefactor array_aggregates -S main.adb src/my_package.ads --remove-indices --pipe
