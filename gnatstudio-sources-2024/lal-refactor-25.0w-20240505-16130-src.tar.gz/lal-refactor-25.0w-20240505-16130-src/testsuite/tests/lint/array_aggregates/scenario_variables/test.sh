lalrefactor array_aggregates -P test.gpr -XCONFIG=two -XOTHER_CONFIG=two --remove-indices --pipe
