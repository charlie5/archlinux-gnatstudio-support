lalrefactor array_aggregates -P test.gpr --remove-indices --pipe

