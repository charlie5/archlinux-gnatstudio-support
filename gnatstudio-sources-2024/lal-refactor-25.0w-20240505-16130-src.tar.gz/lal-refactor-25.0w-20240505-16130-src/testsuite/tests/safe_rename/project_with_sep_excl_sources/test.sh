safe_rename -k -P default.gpr -S foo.ads -L 1 -R 10 -N Qux --algorithm=analyse_ast
