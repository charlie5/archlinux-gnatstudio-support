#!/bin/sh
safe_rename -P test.gpr -S test.adb -L 2 -R 7 -N G --algorithm analyse_ast
