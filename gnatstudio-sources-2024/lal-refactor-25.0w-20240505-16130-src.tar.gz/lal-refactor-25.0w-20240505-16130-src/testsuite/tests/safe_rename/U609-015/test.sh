safe_rename -P default.gpr -S main.adb -L 8 -R 13 --algorithm=analyse_ast -N Foo_Bar
safe_rename -P default.gpr -S main.adb -L 13 -R 9 --algorithm=analyse_ast -N Foo_Bar
