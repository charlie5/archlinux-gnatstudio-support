safe_rename -P default.gpr -S main.adb -L 3 -R 19 -N Foo --algorithm=analyse_ast
