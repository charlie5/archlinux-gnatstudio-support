safe_rename -P default.gpr -S bar.ads -L 3 -R 14 -N F1 --algorithm=analyse_ast
safe_rename -P default.gpr -S bar.ads -L 3 -R 14 -N F2 --algorithm=analyse_ast
safe_rename -P default.gpr -S bar.ads -L 3 -R 14 -N F3 --algorithm=analyse_ast
