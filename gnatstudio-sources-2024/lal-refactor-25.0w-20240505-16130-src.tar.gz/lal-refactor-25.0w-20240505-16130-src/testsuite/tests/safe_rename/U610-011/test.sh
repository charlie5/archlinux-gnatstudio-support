safe_rename -P default.gpr -S test.ads -L 2 -R 13 -N Bar --algorithm=analyse_ast
safe_rename -P default.gpr -S test.ads -L 3 -R 13 -N Baz --algorithm=analyse_ast
safe_rename -P default.gpr -S test.ads -L 4 -R 14 -N Qux --algorithm=analyse_ast
