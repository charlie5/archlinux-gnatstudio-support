#!/bin/sh
safe_rename  -P test.gpr -S corge.ads -L 1 -R 10 -N Fox --algorithm analyse_ast
