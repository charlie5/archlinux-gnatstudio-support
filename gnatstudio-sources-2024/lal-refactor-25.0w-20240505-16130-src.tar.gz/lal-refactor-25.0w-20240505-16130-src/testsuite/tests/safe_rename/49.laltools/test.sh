safe_rename -P test.gpr -S test.adb -L 4 -R 16 -N Number --algorithm analyse_ast
