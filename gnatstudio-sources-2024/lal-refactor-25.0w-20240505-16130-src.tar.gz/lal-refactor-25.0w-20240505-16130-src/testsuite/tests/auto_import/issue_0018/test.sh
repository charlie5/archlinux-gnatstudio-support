auto_import -P prj.gpr --source src/mylib/mylib-timestampedlogger.ads --line 2 --column 48
