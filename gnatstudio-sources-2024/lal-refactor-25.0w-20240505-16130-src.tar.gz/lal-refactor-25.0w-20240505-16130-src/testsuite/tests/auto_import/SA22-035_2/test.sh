#!/bin/sh
auto_import -P default.gpr --source ./src/a.adb --line 49 --column 16
