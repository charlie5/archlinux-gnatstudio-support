#!/bin/sh
auto_import -P default.gpr --source ./src/main.adb --line 3 --column 4
