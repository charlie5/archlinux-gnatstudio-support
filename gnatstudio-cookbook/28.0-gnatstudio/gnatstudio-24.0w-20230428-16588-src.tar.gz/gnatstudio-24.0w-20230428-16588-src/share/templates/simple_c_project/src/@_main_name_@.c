int @_main_name_@(void) {

    //  Insert code here.
    return 0;

}
