#include "cairoint.h"

/**
  * cairo_set_line_join:
  * @cr: a cairo context
  * @line_join: a line join style
  *
  **/
void
cairo_set_line_join (cairo_t *cr, cairo_line_join_t line_join)
{
}
