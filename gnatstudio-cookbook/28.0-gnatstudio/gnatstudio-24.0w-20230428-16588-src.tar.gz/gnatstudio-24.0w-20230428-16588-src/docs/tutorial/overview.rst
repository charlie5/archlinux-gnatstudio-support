***************************************
Quick overview of the GNAT Studio areas
***************************************

Having launched GNAT Studio, you should now have access to a main window
composed of several areas:

* a menu bar at the top
* a tool bar under the menu bar
* on the left, a notebook allowing you to switch between Project, Outline and Scenario views
* the working area in the center
* the Messages window at the bottom

