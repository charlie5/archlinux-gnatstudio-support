**********
Call Trees
**********

Now go back to the file :file:`instructions.adb`, move the mouse over the
procedure *Read* at line 12, select the contextual menu
`Call Trees->Sdc is called by`: this will open a new window titled
`Call Trees` that will allow you to explore the call tree for this
subprogram.
