This directory contains files generated from the Unicode Character Database.

Don't edit them, any changes will be overwritten by the code generator.
