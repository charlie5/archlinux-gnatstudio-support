This directory is used as ALS home directory for the testsuite
