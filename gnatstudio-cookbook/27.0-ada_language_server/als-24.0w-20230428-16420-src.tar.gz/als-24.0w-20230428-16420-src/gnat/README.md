Provided packages
-----------------

 * LSP - Ada implementation of LSP messages and codecs to/from JSON
 * LSP_Server - server part of the LSP protocol and Ada LSP server
 * LSP_Client - client part of the LSP protocol
 * Tester - Test driver for LSP server testsuite
 * Codec_Test - Test driver for Codec tests
