# feature name

## Short introduction

Short introduction describes purpose of the extension.

## Capabilities [optional]

Provide a description of additional capabilities of `Initialize` request if required.

## Change description

This section describes what requests, responses and notifications are changed.
It includes TypeScript definitions as official specification does.

### See also [optional]
This section includes related feature description documents and links to others
related resources.

