# initializationOptions

## Short introduction

The ALS reads initial configuration from the `initializationOptions`
property of the `initialize` request.

## Change description

The `initializationOptions` of the `initialize` request is a JSON
object to be processed as `ada` object of `workspace/didChangeConfiguration`
notification.
