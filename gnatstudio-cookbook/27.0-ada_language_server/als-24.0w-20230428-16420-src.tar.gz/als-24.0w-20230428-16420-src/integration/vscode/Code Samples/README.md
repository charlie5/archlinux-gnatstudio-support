$ Code samples

Here is some code samples for the Ada Language Server and the VS Code extension.

* [Hello world](hello/) - simple project to ge started with VS Code
* [Docker](docker/) - example using Ada with Remote/Container VS Code feature
* [Gnatprove](gnatprove/) - SPARK/gnatprove integration example
* [Refactoring demos](refactoring_demos/) - sample code to check refactoring capabilities
* [Custom worspace-specific environment](custom_env/) - example showing how to set workspace-specific environment variables
