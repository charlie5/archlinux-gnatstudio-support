from test_support import *

gprbuild('include2')
run('include2')
