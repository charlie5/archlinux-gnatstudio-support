from test_support import *

run('testme', ["testme9.tmplt"])
run('print_tree', ["testme9.tmplt"])
