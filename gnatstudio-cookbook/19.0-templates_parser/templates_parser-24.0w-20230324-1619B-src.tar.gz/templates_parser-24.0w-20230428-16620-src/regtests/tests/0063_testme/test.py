from test_support import *

run('testme', ["testme62.tmplt"])
