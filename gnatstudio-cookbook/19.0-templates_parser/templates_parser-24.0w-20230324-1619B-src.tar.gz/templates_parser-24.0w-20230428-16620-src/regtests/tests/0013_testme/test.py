from test_support import *

run('testme', ["testme24.tmplt"])
run('print_tree', ["testme24.tmplt"])
