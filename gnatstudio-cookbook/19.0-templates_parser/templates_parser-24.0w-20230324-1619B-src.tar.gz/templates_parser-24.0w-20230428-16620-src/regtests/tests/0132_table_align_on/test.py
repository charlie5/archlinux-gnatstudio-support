from test_support import *

run('testme', ["align_on.tmplt"])
run('print_tree', ["align_on.tmplt"])
