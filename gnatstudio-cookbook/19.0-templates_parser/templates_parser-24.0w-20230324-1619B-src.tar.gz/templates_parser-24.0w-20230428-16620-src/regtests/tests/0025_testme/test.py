from test_support import *

run('testme', ["testme78.tmplt"])
run('print_tree', ["testme78.tmplt"])
