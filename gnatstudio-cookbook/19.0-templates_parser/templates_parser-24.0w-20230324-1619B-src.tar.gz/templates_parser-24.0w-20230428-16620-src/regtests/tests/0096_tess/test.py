from test_support import *

gprbuild('tess')
run('tess')
