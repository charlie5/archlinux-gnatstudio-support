from test_support import *

run('testme', ["testme79.tmplt"])
