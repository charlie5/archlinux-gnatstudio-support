from test_support import *

run('testme', ["testme66.tmplt"])
