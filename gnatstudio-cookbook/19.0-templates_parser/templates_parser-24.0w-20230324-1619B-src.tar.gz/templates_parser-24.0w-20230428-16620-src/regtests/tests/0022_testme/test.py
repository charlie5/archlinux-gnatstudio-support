from test_support import *

run('testme', ["testme54.tmplt"])
run('print_tree', ["testme54.tmplt"])
