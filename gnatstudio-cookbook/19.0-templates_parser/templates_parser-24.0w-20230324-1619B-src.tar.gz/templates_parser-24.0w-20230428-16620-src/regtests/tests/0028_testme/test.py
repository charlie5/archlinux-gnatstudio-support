from test_support import *

run('testme', ["testme12.tmplt"])
