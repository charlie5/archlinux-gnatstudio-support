from test_support import *

run('testme', ["testme7.tmplt"])
run('print_tree', ["testme7.tmplt"])
