from test_support import *

gprbuild('alo3')
run('alo3')
