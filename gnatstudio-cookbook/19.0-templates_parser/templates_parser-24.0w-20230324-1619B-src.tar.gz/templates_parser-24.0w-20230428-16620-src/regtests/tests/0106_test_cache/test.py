from test_support import *

run('testme', ["testme76.tmplt", "cache"])
