from test_support import gprbuild, run

gprbuild('strip_filter')
run('strip_filter')
