from test_support import *

run('testme', ["testme35.tmplt"])
