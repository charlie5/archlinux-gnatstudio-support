from test_support import *

run('testme', ["blocks3.tmplt"])
run('print_tree', ["blocks3.tmplt"])
