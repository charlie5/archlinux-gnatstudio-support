from test_support import *

gprbuild('regtst2')
run('regtst2')
