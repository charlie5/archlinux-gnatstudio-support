from test_support import *

gprbuild('tag_report')
run('tag_report')
