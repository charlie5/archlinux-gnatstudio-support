from test_support import *

run('testme', ["testme48.tmplt"])
