from test_support import *

gprbuild('ii')
run('ii')
