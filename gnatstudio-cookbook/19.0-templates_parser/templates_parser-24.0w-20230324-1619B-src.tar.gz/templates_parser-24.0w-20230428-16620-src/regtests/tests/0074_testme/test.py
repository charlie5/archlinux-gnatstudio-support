from test_support import *

run('testme', ["testme74.tmplt"])
