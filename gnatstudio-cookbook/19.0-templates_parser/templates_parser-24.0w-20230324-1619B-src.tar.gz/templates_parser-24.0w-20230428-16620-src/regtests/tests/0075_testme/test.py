from test_support import *

run('testme', ["testme75.tmplt"])
