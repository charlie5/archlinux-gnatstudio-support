from test_support import *

run('testme', ["testme18.tmplt"])
run('print_tree', ["testme18.tmplt"])
