from test_support import *

gprbuild('alo')
run('alo')
