from test_support import *

gprbuild('dynamic')
run('dynamic')
