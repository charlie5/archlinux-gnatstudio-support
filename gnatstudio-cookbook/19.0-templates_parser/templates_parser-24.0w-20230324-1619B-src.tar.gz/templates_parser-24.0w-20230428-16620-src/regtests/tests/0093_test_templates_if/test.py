from test_support import *

gprbuild('test_templates_if')
run('test_templates_if')
