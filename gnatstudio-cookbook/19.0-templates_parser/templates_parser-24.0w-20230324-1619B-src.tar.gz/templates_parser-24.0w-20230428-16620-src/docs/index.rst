Templates Parser: A template engine
===================================

.. toctree::
   :numbered:
   :maxdepth: 3

   introduction
   tags
   template_statements
   macros
   other_services
   apiref

Copyright (C) 1999-2004, Pascal Obry

Copyright (C) 2005-2015, AdaCore

This document may be copied, in whole or in part, in any form or by any
means, as is or with alterations, provided that (1) alterations are clearly
marked as alterations and (2) this copyright notice is included
unmodified in any copy.
