extern "C" {
void test(void) {}
}

