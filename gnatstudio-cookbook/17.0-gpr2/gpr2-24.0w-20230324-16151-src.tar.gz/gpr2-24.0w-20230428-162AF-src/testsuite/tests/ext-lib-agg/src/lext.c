#include <stdio.h>

extern void lext_print() {
   puts("External library test output");
}
