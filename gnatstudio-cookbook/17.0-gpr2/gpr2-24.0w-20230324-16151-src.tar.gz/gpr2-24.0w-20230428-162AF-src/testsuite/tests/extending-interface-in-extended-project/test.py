from testsuite_support.builder_and_runner import BuilderAndRunner, GPRLS

BuilderAndRunner().call([GPRLS, "-Pimp4/imp4"])
