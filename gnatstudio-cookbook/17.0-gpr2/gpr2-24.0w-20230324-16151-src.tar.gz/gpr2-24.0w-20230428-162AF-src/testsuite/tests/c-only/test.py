from testsuite_support.builder_and_runner import BuilderAndRunner, GPRCLEAN

BuilderAndRunner().call([GPRCLEAN, "prj.gpr"])
