const char hello[] = "Hello there!";
