#include "resources.h"
#include <stdio.h>

int main(void) {
  printf("%s\n", hello);
}
