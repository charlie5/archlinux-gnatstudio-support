#include <stdio.h>
void toto (void)
{
   printf ("Toto\n");
}

