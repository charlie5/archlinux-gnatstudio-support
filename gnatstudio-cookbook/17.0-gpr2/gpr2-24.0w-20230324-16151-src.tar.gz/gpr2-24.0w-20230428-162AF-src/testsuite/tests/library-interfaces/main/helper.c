#include <mylib.h>

int get_i(void) {
  return mylib__i;
}
