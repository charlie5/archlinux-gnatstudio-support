
extern int mylib__i;
