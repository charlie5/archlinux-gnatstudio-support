#include "test1.h"
int f(void) {
	return 0;
}
