#include <stdio.h>
void ccall (void)
{
  printf ("From C\n");
}
