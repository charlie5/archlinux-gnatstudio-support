/* Helper to format the name of a symbol for the NAME generated library.  */

#ifndef LIB_SYMBOL
#define LIB_SYMBOL(name) foo_##name
#endif /* LIB_SYMBOL */
