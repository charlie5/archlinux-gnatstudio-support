GNATcoll Bindings - Python
==========================

This component uses the ``GNATCOLL.Scripts`` API to provide interfacing with
Python. Please refer to its documentation for an introduction to
``GNATCOLL.Scripts``.
