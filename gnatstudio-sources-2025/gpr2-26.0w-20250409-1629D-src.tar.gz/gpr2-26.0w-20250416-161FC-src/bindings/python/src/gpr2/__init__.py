#
#  Copyright (C) 2020, AdaCore
#
#  SPDX-License-Identifier: Apache-2.0
#

class GPR2Error(Exception):
    pass
