.. only:: LEGACY_WARNING

.. warning::

   This is not implemented yet in gprbuild or GNATcoll.Projects-based
   tools such as GNATstudio.
