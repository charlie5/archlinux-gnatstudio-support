The GNAT Components Collection (GNATCOLL) - GMP
===============================================

This is the GMP component of the GNAT Components Collection.

It is an interface to the GNU Multiple Precision (GMP) arithmetic library.

Dependencies
------------

This component requires the following external components, that should be
available on your system:

- gprbuild
- gnatcoll-core
- gmp
