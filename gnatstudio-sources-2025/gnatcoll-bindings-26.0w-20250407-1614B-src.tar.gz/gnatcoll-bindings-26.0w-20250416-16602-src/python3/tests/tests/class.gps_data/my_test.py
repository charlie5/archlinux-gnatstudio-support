from Test import My_Class

m = My_Class("FooBar")
assert m.Get_Property() == "FooBar"
print('<=== TEST PASSED ===>')
