from Test import My_Class

assert My_Class.Hello() == "Hello World!"
print('<=== TEST PASSED ===>')
