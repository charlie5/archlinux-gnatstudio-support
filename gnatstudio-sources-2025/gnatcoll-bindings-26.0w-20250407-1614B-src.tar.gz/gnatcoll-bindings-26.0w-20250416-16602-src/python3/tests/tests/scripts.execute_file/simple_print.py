print('Hello from python binding')
