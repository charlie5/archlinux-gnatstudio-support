from test_support import *

gprbuild('ts_assoc')
run('ts_assoc')
