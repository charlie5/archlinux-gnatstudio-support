from test_support import *

run('testme', ["testme71.tmplt"])
