from test_support import *

gprbuild('trans_set')
run('trans_set')
