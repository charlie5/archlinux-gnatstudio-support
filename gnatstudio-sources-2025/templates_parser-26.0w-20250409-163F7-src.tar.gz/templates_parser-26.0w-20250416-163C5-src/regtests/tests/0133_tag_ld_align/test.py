from test_support import *

run('testme', ["tag_cr_align.tmplt"])
