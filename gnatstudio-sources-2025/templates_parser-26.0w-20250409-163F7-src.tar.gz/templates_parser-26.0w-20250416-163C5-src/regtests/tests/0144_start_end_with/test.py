from test_support import *

run('testme', ["testme144.tmplt"])
