from test_support import *

run('testme', ["blocks6.tmplt"])
run('print_tree', ["blocks6.tmplt"])
