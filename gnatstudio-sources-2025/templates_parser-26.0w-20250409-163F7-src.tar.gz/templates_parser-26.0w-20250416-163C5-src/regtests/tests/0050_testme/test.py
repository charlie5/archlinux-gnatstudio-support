from test_support import *

run('testme', ["testme46.tmplt"])
