from test_support import *

run('testme', ["testme16.tmplt"])
run('print_tree', ["testme16.tmplt"])
