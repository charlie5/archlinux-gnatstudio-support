from test_support import *

run('testme', ["testme145.tmplt"])
