from test_support import *

run('testme', ["testme65.tmplt"])
