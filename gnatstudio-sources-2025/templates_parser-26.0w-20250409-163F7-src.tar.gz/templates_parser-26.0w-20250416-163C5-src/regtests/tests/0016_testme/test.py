from test_support import *

run('testme', ["testme27.tmplt"])
run('print_tree', ["testme27.tmplt"])
