from test_support import *

run('testme', ["testme40.tmplt"])
