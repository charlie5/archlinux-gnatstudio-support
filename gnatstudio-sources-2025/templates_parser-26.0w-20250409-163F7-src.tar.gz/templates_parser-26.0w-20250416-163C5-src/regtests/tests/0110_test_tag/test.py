from test_support import *
import os

gprbuild('test_tag')
run('test_tag')
