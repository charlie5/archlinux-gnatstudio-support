from test_support import *

gprbuild('tcache')
run('tcache')
