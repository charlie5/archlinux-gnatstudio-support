from test_support import *

gprbuild('user_filter')
run('user_filter')
