from test_support import *

gprbuild('testcat')
run('testcat')
