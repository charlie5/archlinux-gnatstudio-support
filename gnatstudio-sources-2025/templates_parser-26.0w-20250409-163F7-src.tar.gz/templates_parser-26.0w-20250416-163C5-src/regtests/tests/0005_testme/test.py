from test_support import *

run('testme', ["testme6.tmplt"])
run('print_tree', ["testme6.tmplt"])
