from test_support import *

run('testme', ["testme80.tmplt"])
run('print_tree', ["testme80.tmplt"])
