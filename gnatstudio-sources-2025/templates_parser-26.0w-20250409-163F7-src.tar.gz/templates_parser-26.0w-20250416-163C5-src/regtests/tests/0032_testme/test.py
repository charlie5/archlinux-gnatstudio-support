from test_support import *

run('testme', ["testme20.tmplt"])
