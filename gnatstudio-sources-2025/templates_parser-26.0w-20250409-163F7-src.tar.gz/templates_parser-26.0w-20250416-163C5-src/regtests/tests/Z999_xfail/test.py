import sys
import time

from test_support import *

print(time.strftime("%y-%m-%d %H:%M", time.localtime()))
