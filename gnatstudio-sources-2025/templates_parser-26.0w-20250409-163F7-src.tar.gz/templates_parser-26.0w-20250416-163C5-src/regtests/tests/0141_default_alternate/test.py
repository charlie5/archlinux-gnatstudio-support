from test_support import *

run('testme', ["testme141.tmplt"])
