from test_support import *

run('testme', ["with_bom.tmplt"])
run('print_tree', ["with_bom.tmplt"])
