from test_support import *

run('testme', ["testme4.tmplt"])
