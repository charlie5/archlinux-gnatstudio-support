from test_support import *

run('testme', ["macro_filter.tmplt"])
run('print_tree', ["macro_filter.tmplt"])
