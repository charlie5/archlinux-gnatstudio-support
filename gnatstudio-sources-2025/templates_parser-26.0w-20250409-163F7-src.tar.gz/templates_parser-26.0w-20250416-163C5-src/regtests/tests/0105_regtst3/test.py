from test_support import *

gprbuild('regtst3')
run('regtst3')
