from test_support import *

run('testme', ["blocks2.tmplt"])
