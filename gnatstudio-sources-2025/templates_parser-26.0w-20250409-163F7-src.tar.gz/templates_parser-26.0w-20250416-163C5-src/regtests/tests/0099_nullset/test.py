from test_support import *

gprbuild('nullset')
run('nullset')
