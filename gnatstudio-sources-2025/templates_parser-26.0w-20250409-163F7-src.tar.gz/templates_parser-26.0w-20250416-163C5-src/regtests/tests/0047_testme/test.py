from test_support import *

run('testme', ["testme43.tmplt"])
