from test_support import *

gprbuild('alo2')
run('alo2')
