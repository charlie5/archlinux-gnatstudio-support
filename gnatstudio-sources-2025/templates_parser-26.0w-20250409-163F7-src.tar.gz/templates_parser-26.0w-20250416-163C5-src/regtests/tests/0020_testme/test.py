from test_support import *

run('testme', ["testme38.tmplt"])
run('print_tree', ["testme38.tmplt"])
