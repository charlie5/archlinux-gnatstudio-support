from test_support import *

run('testme', ["testme22.tmplt"])
