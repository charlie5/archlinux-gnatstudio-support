from test_support import *

run('testme', ["testme2.tmplt"])
run('print_tree', ["testme2.tmplt"])
