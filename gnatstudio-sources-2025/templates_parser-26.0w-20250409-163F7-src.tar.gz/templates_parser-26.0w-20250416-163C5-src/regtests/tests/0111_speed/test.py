from test_support import *

gprbuild('speed')
run('speed')
