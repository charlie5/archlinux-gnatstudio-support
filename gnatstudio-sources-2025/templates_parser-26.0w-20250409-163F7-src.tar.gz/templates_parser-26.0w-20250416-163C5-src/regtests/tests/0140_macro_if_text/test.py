from test_support import *

run('testme', ["testmacrotxt.tmplt"])
