from test_support import *

run('testme', ["testme59.tmplt"])
run('print_tree', ["testme59.tmplt"])
