from test_support import *

gprbuild('regtst4')
run('regtst4')
