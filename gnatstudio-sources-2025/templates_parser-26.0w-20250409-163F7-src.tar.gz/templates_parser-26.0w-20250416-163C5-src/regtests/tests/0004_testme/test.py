from test_support import *

run('testme', ["testme5.tmplt"])
run('print_tree', ["testme5.tmplt"])
