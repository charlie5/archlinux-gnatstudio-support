from test_support import *

run("testme", ["testme63.tmplt"])
