from test_support import *

run('testme', ["testme15.tmplt"])
run('print_tree', ["testme15.tmplt"])
