lalrefactor --help
