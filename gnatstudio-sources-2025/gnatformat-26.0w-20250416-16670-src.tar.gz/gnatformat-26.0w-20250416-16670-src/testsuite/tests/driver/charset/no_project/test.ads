package Test is
   Indicator_Nice : constant array (Indicator_Range) of Wide_Wide_Character :=
     ('◴', '◷', '◶', '◵');
end Test;
