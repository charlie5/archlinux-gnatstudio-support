procedure Test is
   --  begin read only
   A :
   constant B
   := C;
   --  end read only
   begin
   null;
end Test;
