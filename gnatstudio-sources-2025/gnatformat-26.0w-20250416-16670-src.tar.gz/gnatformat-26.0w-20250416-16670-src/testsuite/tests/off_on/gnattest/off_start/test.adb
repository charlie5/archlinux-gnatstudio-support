--  begin read only
procedure Test is
   A :
   constant B
   := C;
   begin
   null;
end Test;
