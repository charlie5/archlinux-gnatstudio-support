XML/Ada: The Unicode and XML Library for Ada
============================================

.. toctree::
   :numbered:
   :maxdepth: 3

   intro
   unicode
   input
   sax
   dom
   schema
   using

Copyright (C) 2000-2002, Emmanuel Briot

Copyright (C) 2003-2011, AdaCore

This document may be copied, in whole or in part, in any form or by any
means, as is or with alterations, provided that (1) alterations are clearly
marked as alterations and (2) this copyright notice is included
unmodified in any copy.

