GNATX template project
======================

This project just exists to showcase the use of the experimental features flag
in a project using Libadalang.
