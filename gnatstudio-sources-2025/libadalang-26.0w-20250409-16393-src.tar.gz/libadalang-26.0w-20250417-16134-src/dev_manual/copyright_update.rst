****************
Copyright update
****************

At the beginning of each year, the copyright notices should be updated to cover
the new year. The ``utils/update_copyright.py`` script automates this task.
With a standard Libadalang/Langkit/AdaSAT repositories layout, run it from the
Libadalang checkout root:

.. code-block:: sh

   libadalang$ utils/update_copyright.py

Then commit the resulting changes in the three repositories.
