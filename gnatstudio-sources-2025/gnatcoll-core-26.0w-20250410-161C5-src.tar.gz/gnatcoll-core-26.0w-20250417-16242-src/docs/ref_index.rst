.. only:: html

    GNATCOLL Reference
    ==================

    GNATCOLL Minimal
    ----------------

    .. toctree::
       :glob:

       refs/minimal/ref-*

    GNATCOLL Core
    -------------

    .. toctree::
       :glob:

       refs/core/ref-*

    GNATCOLL Projects
    -----------------

    .. toctree::
       :glob:

       refs/projects/ref-*


