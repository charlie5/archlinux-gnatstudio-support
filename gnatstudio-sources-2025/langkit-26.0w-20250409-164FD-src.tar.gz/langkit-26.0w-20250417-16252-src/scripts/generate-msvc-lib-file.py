#! /usr/bin/env python

from langkit.scripts.generate_msvc_lib_file import main


main()
