.. Langkit documentation master file, created by
   sphinx-quickstart on Wed Aug 12 12:28:45 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Langkit's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   tutorial
   extension_points
   api_documentation
   properties_dsl
   lexical_envs
   java_bindings
   internals/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
