# Just make sure the generated library looks viable

print("main.py: Running...")


import libfoolang


del libfoolang
print("main.py: Done.")
