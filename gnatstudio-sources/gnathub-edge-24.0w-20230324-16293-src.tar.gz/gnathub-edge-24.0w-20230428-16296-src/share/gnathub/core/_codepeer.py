# GNAThub (GNATdashboard)
# Copyright (C) 2013-2015, AdaCore
#
# This is free software;  you can redistribute it  and/or modify it  under
# terms of the  GNU General Public License as published  by the Free Soft-
# ware  Foundation;  either version 3,  or (at your option) any later ver-
# sion.  This software is distributed in the hope  that it will be useful,
# but WITHOUT ANY WARRANTY;  without even the implied warranty of MERCHAN-
# TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
# License for  more details.  You should have  received  a copy of the GNU
# General  Public  License  distributed  with  this  software;   see  file
# COPYING3.  If not, go to http://www.gnu.org/licenses for a complete copy
# of the license.

"""Provide common components to CodePeer."""

from shutil import which
import subprocess

# Known versions of CodePeer/ GNATSAS
LEGACY = 0
CPL = 1
GNATSAS = 2
# Start of unknown versions
TOO_RECENT = 3

if which("gnatsas-revision") is None:
    version = LEGACY
else:
    revision = int(subprocess.getoutput("gnatsas-revision"))
    if revision < LEGACY:
        error(f'unknown GNATSAS revision {revision}')
    elif revision >= TOO_RECENT:
        log.warn(f'unknown GNATSAS revision {revision}' +
                      'upgrade GNAThub in case of failures')
        # Use the last known version and pray it will work.
        version = TOO_RECENT - 1
    else:
        version = revision
