Contributing to Libadalang-tools
================================

Thank you for taking the time to contribute!

If this is your first contribution, we invite you to read our [list of
guidelines](https://github.com/AdaCore/contributing-howto), common to all
AdaCore repositories.
