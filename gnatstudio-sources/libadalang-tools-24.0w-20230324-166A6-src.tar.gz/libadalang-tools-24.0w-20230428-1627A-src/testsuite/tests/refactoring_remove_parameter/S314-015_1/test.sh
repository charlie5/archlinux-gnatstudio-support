#!/bin/sh
remove_parameter -P default.gpr -S main.adb -L 7 -R 32
remove_parameter -P default.gpr -S main_package-xyzzy.adb -L 1 -R 44