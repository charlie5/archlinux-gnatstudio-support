#!/bin/sh
remove_parameter -P default.gpr -S main.adb -L 4 -R 43
