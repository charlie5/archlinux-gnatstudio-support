#!/bin/sh
remove_parameter -P default.gpr -S main_package.ads -L 5 -R 10
remove_parameter -P default.gpr -S main_package.ads -L 6 -R 17
