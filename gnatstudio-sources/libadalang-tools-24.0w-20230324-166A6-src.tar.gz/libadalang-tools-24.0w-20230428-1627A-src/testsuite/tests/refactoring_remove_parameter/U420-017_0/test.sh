remove_parameter -P default.gpr -S foo.ads -L 3 -R 19
