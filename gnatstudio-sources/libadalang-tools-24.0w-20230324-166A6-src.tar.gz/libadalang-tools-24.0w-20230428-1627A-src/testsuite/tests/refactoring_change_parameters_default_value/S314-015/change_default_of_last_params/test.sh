change_parameters_default_value -P test.gpr --source=src/my_lib.ads --start-line=2 --start-column=24 --end-line=2 --end-column=24 --new-parameter-default-value=2
