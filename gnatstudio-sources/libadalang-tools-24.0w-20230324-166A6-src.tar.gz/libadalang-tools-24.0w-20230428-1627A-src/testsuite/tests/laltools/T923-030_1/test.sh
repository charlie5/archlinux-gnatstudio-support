#!/bin/sh
refactor_imports -P default.gpr -S ./src/main.adb -L 3 -R 4
