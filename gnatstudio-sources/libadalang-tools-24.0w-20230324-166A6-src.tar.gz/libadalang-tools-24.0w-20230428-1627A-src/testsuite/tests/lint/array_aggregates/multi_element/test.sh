gnatrefactor array_aggregates -P test.gpr --pipe
