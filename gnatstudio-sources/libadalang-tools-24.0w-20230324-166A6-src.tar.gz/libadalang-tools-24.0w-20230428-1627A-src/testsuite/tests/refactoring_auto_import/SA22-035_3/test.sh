#!/bin/sh
refactor_imports -P default.gpr -S ./src/a.adb -L 46 -R 20
