#!/bin/sh
refactor_imports -P default.gpr -S ./src/main.adb -L 4 -R 4
