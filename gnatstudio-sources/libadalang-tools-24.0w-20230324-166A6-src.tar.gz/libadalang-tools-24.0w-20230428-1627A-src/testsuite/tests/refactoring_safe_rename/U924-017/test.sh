safe_rename -P default.gpr -S foo.ads -L 2 -R 18 -N This --algorithm=analyse_ast
safe_rename -P default.gpr -S foo.ads -L 3 -R 35 -N T --algorithm=analyse_ast
safe_rename -P default.gpr -S foo.ads -L 4 -R 20 -N This --algorithm=analyse_ast
