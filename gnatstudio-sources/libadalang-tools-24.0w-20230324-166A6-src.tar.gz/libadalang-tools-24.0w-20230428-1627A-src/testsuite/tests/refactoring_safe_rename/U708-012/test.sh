safe_rename -k -P default.gpr -S baz.ads -L 2 -R 4 -N T --algorithm=analyse_ast
