#!/bin/sh
safe_rename -P default.gpr -S ./src/main.adb -L 6 -R 4 -N Baz
