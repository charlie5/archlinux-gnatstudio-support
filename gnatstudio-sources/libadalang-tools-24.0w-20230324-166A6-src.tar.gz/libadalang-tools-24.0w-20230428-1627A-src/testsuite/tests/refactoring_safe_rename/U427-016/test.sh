safe_rename -P default.gpr -S main.adb -L 8 -R 4 -N Foo --algorithm analyse_ast
safe_rename -P default.gpr -S main.adb -L 8 -R 4 -N Bar --algorithm analyse_ast
safe_rename -P default.gpr -S main.adb -L 8 -R 4 -N Cursor --algorithm analyse_ast
safe_rename -P default.gpr -S main.adb -L 8 -R 4 -N List --algorithm analyse_ast
safe_rename -P default.gpr -S main.adb -L 8 -R 4 -N File_Type --algorithm analyse_ast
