safe_rename -P default.gpr -S main.adb -L 3 -R 7 -N Qux --algorithm=analyse_ast
