safe_rename -P default.gpr -S foo.adb -L 4 -R 7 -N E --algorithm=analyse_ast
