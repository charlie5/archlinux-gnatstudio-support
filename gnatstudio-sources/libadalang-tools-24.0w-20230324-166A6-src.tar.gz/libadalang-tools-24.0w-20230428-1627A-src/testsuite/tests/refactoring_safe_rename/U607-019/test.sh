safe_rename -k -P default -S baz.ads -L 3 -R 18 -N B --algorithm analyse_ast
