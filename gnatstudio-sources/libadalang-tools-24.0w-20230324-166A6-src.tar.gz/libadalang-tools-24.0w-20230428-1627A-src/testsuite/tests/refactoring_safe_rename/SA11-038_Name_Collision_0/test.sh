#!/bin/sh
safe_rename  -P default.gpr -S ./src/main.adb -L 5 -R 14 -N B --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 5 -R 14 -N C1 --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 5 -R 14 -N D --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 5 -R 14 -N E --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 5 -R 14 -N F --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 5 -R 14 -N G --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 5 -R 14 -N H --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 49 -R 13 -N I --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 49 -R 13 -N J --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 49 -R 13 -N K --algorithm analyse_ast
safe_rename  -P default.gpr -S ./src/main.adb -L 49 -R 13 -N L --algorithm analyse_ast
