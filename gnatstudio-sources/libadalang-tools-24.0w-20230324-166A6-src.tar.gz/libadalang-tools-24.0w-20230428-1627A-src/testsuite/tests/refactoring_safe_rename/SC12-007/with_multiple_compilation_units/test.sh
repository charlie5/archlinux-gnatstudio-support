#!/bin/sh
safe_rename  -P test.gpr -S qux.1.ada -L 1 -R 10 -N Fox --algorithm analyse_ast
