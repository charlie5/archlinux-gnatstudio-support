#!/bin/sh
safe_rename  -P test.gpr -S Test.2.ada -L 1 -R 6 -N Fox --algorithm analyse_ast
