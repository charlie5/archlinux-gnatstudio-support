safe_rename -P default.gpr -S qux.ads -L 3 -R 13 -N Dummy_B --algorithm=analyse_ast
safe_rename -P default.gpr -S qux.ads -L 3 -R 13 -N Dummy_C --algorithm=analyse_ast
safe_rename -P default.gpr -S qux.ads -L 3 -R 13 -N Dummy_D --algorithm=analyse_ast
safe_rename -P default.gpr -S qux.ads -L 6 -R 13 -N Dummy_E --algorithm=analyse_ast
safe_rename -P default.gpr -S qux.ads -L 3 -R 13 -N Dummy_F --algorithm=analyse_ast
safe_rename -P default.gpr -S qux.ads -L 6 -R 13 -N Dummy_F --algorithm=analyse_ast
