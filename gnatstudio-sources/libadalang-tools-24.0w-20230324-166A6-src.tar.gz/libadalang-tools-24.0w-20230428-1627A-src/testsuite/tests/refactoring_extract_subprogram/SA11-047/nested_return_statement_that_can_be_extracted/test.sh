extract_subprogram -P default.gpr -S my_package.adb -SL 6 -SC 8 -EL 6 -EC 9 -N Foo
