gnatpp --pipe main.adb
echo ""
gnatpp --pipe -cN main.adb
echo ""
gnatpp --pipe -cD main.adb
echo ""
gnatpp --pipe -cU main.adb
echo ""
gnatpp --pipe -cL main.adb
echo ""
gnatpp --pipe -cM main.adb
