gnatpp -q --pipe spark_mode.ads
