gnatpp -q -P pretty.gpr Pretty.adb -pipe
gnatpp -q -P pretty.gpr Pretty.adb -pipe --vertical-enum-types --vertical-named-aggregates
