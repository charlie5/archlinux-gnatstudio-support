gnatpp example_with_comments.ads --pipe
gnatpp new_example_with_comments.ads --pipe
