gnatpp ors.adb --pipe
