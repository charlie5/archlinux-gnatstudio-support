gnatpp --pipe p.ads
gnatpp --pipe q.ads
