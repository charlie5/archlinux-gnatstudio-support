gnatpp -q --pipe cvt_example.ada
