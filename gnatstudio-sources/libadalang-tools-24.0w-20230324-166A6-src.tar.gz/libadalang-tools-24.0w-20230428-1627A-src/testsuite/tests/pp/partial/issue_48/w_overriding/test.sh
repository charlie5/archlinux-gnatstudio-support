partial_gnatpp -P default.gpr -S test.ads -SL 8 -SC 20 -EL 8 -EC 22
partial_gnatpp -P default.gpr -S test.ads -SL 8 -SC 5 -EL 8 -EC 22
partial_gnatpp -P default.gpr -S test.adb -SL 4 -SC 9 -EL 4 -EC 13
partial_gnatpp -P default.gpr -S test.adb -SL 2 -SC 5 -EL 4 -EC 13
