partial_gnatpp -P default.gpr -S main.adb -SL 3 -SC 1 -EL 4

partial_gnatpp -P default.gpr -S main.adb -SL 5 -SC 1 -EL 6



