gnatpp --pipe --indentation=2 records.ada
gnatpp --pipe --indentation=2 --split-line-before-record records.ada
