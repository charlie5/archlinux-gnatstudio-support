gnatpp --pipe --vertical-enum-types -P Debug.gpr test_main.adb
