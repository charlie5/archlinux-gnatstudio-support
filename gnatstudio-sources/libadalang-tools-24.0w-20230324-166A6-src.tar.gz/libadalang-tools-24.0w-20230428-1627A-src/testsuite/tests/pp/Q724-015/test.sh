gnatpp --pipe csc_channel-version_handling.ads
gnatpp --pipe csc_channel-version_handling.ads --no-align-modes
