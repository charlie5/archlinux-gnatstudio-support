gnatpp --pipe --max-line-length=160 --indentation=2 --indent-continuation=1 --vertical-named-aggregates p.ada
