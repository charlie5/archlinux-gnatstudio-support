gnatpp test.adb --pipe

