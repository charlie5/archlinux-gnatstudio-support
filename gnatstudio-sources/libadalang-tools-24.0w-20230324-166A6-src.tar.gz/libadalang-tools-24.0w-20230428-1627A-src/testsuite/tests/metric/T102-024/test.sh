gnatmetric -q -x --no-xml-config --short-file-names --lines-all --complexity-all --coupling-all --syntax-all has_body.adb no_body.adb
cat metrix.xml
