gnatpp -P p.gpr --pipe foo.adb
gnatmetric --short-file-names -P p.gpr foo.adb
