gnatmetric -q -P aggregate_prj.gpr --short-file-names
cat obj/*.metrix
