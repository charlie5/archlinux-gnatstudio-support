Source: https://github.com/altercation/solarized
