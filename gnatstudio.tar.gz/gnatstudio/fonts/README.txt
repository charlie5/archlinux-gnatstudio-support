Add here any fonts for GPS to load.

Supported formats: .ttf, .otf, .ttc.
